//! egui dashboard that acts as the central UDP server for the UWB devices.
//!
//! It binds UDP port 50000 (see protocol.md / msgs.proto) and renders the
//! devices that announce themselves plus, for every tag, the anchors it is
//! ranging with their latest distance and RX power.
//!
//! The protobuf wire format is decoded by hand (no codegen) so the crate only
//! depends on eframe/egui. Field numbers match msgs.proto and uwb_proto.h.

use std::collections::HashMap;
use std::net::UdpSocket;
use std::sync::mpsc;
use std::time::{Duration, Instant};

use eframe::egui;

// --- transport --------------------------------------------------------------
const LISTEN_ADDR: &str = "0.0.0.0:50000";

// --- msg_type values (match msgs.proto / uwb_proto.h) -----------------------
const MSG_ANNOUNCE: u32 = 1;
const MSG_SET_BROKER: u32 = 2;
const MSG_SYS_EVENT: u32 = 3;
const MSG_UWB_ANCHOR_EVENT: u32 = 4;
const MSG_UWB_TAG_EVENT: u32 = 5;

// --- protobuf wire types ----------------------------------------------------
const WIRE_VARINT: u32 = 0;
const WIRE_FIXED64: u32 = 1;
const WIRE_LEN: u32 = 2;
const WIRE_FIXED32: u32 = 5;

// ---------------------------------------------------------------------------
// protobuf decoding
// ---------------------------------------------------------------------------

fn read_varint(buf: &[u8], pos: &mut usize) -> Option<u64> {
    let mut result = 0u64;
    let mut shift = 0u32;
    loop {
        if *pos >= buf.len() || shift >= 64 {
            return None;
        }
        let b = buf[*pos];
        *pos += 1;
        result |= ((b & 0x7f) as u64) << shift;
        if b & 0x80 == 0 {
            return Some(result);
        }
        shift += 7;
    }
}

struct FieldIter<'a> {
    buf: &'a [u8],
    pos: usize,
}

impl<'a> FieldIter<'a> {
    fn new(buf: &'a [u8]) -> Self {
        Self { buf, pos: 0 }
    }

    // Returns (field_number, wire_type) for the next field, or None at end.
    fn next(&mut self) -> Option<(u32, u32)> {
        if self.pos >= self.buf.len() {
            return None;
        }
        let tag = read_varint(self.buf, &mut self.pos)?;
        Some(((tag >> 3) as u32, (tag & 7) as u32))
    }

    fn varint(&mut self) -> Option<u64> {
        read_varint(self.buf, &mut self.pos)
    }

    fn bytes(&mut self) -> Option<&'a [u8]> {
        let n = self.varint()? as usize;
        if self.pos + n > self.buf.len() {
            return None;
        }
        let s = &self.buf[self.pos..self.pos + n];
        self.pos += n;
        Some(s)
    }

    fn fixed32(&mut self) -> Option<f32> {
        if self.pos + 4 > self.buf.len() {
            return None;
        }
        let b: [u8; 4] = self.buf[self.pos..self.pos + 4].try_into().ok()?;
        self.pos += 4;
        Some(f32::from_le_bytes(b))
    }

    fn skip(&mut self, wire: u32) -> Option<()> {
        match wire {
            WIRE_VARINT => {
                self.varint()?;
            }
            WIRE_LEN => {
                let n = self.varint()? as usize;
                if self.pos + n > self.buf.len() {
                    return None;
                }
                self.pos += n;
            }
            WIRE_FIXED64 => {
                if self.pos + 8 > self.buf.len() {
                    return None;
                }
                self.pos += 8;
            }
            WIRE_FIXED32 => {
                if self.pos + 4 > self.buf.len() {
                    return None;
                }
                self.pos += 4;
            }
            _ => return None,
        }
        Some(())
    }
}

#[derive(Debug)]
struct Envelope {
    src: u32,
    #[allow(dead_code)]
    dst: u32,
    msg_type: u32,
    payload: Vec<u8>,
}

fn decode_envelope(buf: &[u8]) -> Option<Envelope> {
    let mut src = 0u32;
    let mut dst = 0u32;
    let mut msg_type = 0u32;
    let mut payload = Vec::new();
    let mut it = FieldIter::new(buf);
    while let Some((field, wire)) = it.next() {
        match field {
            1 => src = it.varint()? as u32,
            2 => dst = it.varint()? as u32,
            3 => msg_type = it.varint()? as u32,
            4 if wire == WIRE_LEN => payload = it.bytes()?.to_vec(),
            _ => it.skip(wire)?,
        }
    }
    Some(Envelope {
        src,
        dst,
        msg_type,
        payload,
    })
}

// --- decoded payloads -------------------------------------------------------

struct Announce {
    device: String,
    ip: Option<[u8; 4]>,
    port: u32,
    msg_types: Vec<u32>,
}

struct SysEvent {
    uptime_ms: u64,
    rssi: i32,
    ip: Option<[u8; 4]>,
    mac: Option<[u8; 6]>,
}

struct UwbAnchorEvent {
    mac: Vec<u8>,
}

struct UwbTagEvent {
    mac: Vec<u8>,
    anchor: Vec<u8>,
    distance_m: f32,
    rx_power_db: f32,
}

struct SetBroker {
    ip: Option<[u8; 4]>,
    port: u32,
}

fn decode_announce(p: &[u8]) -> Option<Announce> {
    let mut it = FieldIter::new(p);
    let mut device = String::new();
    let mut ip = None;
    let mut port = 0u32;
    let mut msg_types = Vec::new();
    while let Some((field, wire)) = it.next() {
        match field {
            1 if wire == WIRE_LEN => device = String::from_utf8_lossy(it.bytes()?).into_owned(),
            2 => {
                if wire == WIRE_LEN {
                    let b = it.bytes()?;
                    let mut pos = 0;
                    while pos < b.len() {
                        msg_types.push(read_varint(b, &mut pos)? as u32);
                    }
                } else if wire == WIRE_VARINT {
                    msg_types.push(it.varint()? as u32);
                } else {
                    it.skip(wire)?;
                }
            }
            3 if wire == WIRE_LEN => {
                let b = it.bytes()?;
                if b.len() == 4 {
                    ip = Some([b[0], b[1], b[2], b[3]]);
                }
            }
            4 if wire == WIRE_VARINT => port = it.varint()? as u32,
            _ => it.skip(wire)?,
        }
    }
    Some(Announce {
        device,
        ip,
        port,
        msg_types,
    })
}

fn decode_sys_event(p: &[u8]) -> Option<SysEvent> {
    let mut it = FieldIter::new(p);
    let mut uptime_ms = 0u64;
    let mut rssi = 0i32;
    let mut ip = None;
    let mut mac = None;
    while let Some((field, wire)) = it.next() {
        match field {
            1 if wire == WIRE_VARINT => uptime_ms = it.varint()?,
            2 if wire == WIRE_LEN => {
                let b = it.bytes()?;
                if b.len() == 6 {
                    mac = Some([b[0], b[1], b[2], b[3], b[4], b[5]]);
                }
            }
            3 if wire == WIRE_LEN => {
                let b = it.bytes()?;
                if b.len() == 4 {
                    ip = Some([b[0], b[1], b[2], b[3]]);
                }
            }
            4 if wire == WIRE_VARINT => rssi = (it.varint()? as u32) as i32,
            _ => it.skip(wire)?,
        }
    }
    Some(SysEvent {
        uptime_ms,
        rssi,
        ip,
        mac,
    })
}

fn decode_uwb_anchor_event(p: &[u8]) -> Option<UwbAnchorEvent> {
    let mut it = FieldIter::new(p);
    let mut mac = Vec::new();
    while let Some((field, wire)) = it.next() {
        match field {
            1 if wire == WIRE_LEN => mac = it.bytes()?.to_vec(),
            _ => it.skip(wire)?,
        }
    }
    Some(UwbAnchorEvent { mac })
}

fn decode_uwb_tag_event(p: &[u8]) -> Option<UwbTagEvent> {
    let mut it = FieldIter::new(p);
    let mut mac = Vec::new();
    let mut anchor = Vec::new();
    let mut distance_m = 0f32;
    let mut rx_power_db = 0f32;
    while let Some((field, wire)) = it.next() {
        match field {
            1 if wire == WIRE_LEN => mac = it.bytes()?.to_vec(),
            2 if wire == WIRE_LEN => anchor = it.bytes()?.to_vec(),
            3 if wire == WIRE_FIXED32 => distance_m = it.fixed32()?,
            4 if wire == WIRE_FIXED32 => rx_power_db = it.fixed32()?,
            _ => it.skip(wire)?,
        }
    }
    Some(UwbTagEvent {
        mac,
        anchor,
        distance_m,
        rx_power_db,
    })
}

fn decode_set_broker(p: &[u8]) -> Option<SetBroker> {
    let mut it = FieldIter::new(p);
    let mut ip = None;
    let mut port = 0u32;
    while let Some((field, wire)) = it.next() {
        match field {
            1 if wire == WIRE_LEN => {
                let b = it.bytes()?;
                if b.len() == 4 {
                    ip = Some([b[0], b[1], b[2], b[3]]);
                }
            }
            2 if wire == WIRE_VARINT => port = it.varint()? as u32,
            _ => it.skip(wire)?,
        }
    }
    Some(SetBroker { ip, port })
}

// --- events pushed from the UDP thread to the UI ----------------------------

#[derive(Debug)]
enum Event {
    Listening {
        addr: String,
    },
    Error(String),
    Announce {
        src: u32,
        device: String,
        ip: Option<[u8; 4]>,
        port: u32,
        msg_types: Vec<u32>,
    },
    Sys {
        src: u32,
        uptime_ms: u64,
        rssi: i32,
        ip: Option<[u8; 4]>,
        mac: Option<[u8; 6]>,
    },
    Anchor {
        src: u32,
        uwb_mac: Vec<u8>,
    },
    Tag {
        src: u32,
        uwb_mac: Vec<u8>,
        anchor: Vec<u8>,
        distance_m: f32,
        rx_power_db: f32,
    },
    SetBroker {
        src: u32,
        ip: Option<[u8; 4]>,
        port: u32,
    },
    Unknown {
        src: u32,
        msg_type: u32,
    },
}

fn decode_payload(src: u32, msg_type: u32, payload: &[u8]) -> Event {
    match msg_type {
        MSG_ANNOUNCE => match decode_announce(payload) {
            Some(a) => Event::Announce {
                src,
                device: a.device,
                ip: a.ip,
                port: a.port,
                msg_types: a.msg_types,
            },
            None => Event::Unknown { src, msg_type },
        },
        MSG_SYS_EVENT => match decode_sys_event(payload) {
            Some(s) => Event::Sys {
                src,
                uptime_ms: s.uptime_ms,
                rssi: s.rssi,
                ip: s.ip,
                mac: s.mac,
            },
            None => Event::Unknown { src, msg_type },
        },
        MSG_UWB_ANCHOR_EVENT => match decode_uwb_anchor_event(payload) {
            Some(a) => Event::Anchor {
                src,
                uwb_mac: a.mac,
            },
            None => Event::Unknown { src, msg_type },
        },
        MSG_UWB_TAG_EVENT => match decode_uwb_tag_event(payload) {
            Some(t) => Event::Tag {
                src,
                uwb_mac: t.mac,
                anchor: t.anchor,
                distance_m: t.distance_m,
                rx_power_db: t.rx_power_db,
            },
            None => Event::Unknown { src, msg_type },
        },
        MSG_SET_BROKER => match decode_set_broker(payload) {
            Some(b) => Event::SetBroker {
                src,
                ip: b.ip,
                port: b.port,
            },
            None => Event::Unknown { src, msg_type },
        },
        _ => Event::Unknown { src, msg_type },
    }
}

// --- helpers ----------------------------------------------------------------

fn fmt_ip(ip: Option<[u8; 4]>) -> String {
    match ip {
        Some(b) => format!("{}.{}.{}.{}", b[0], b[1], b[2], b[3]),
        None => "?".to_string(),
    }
}

fn hex_bytes(b: &[u8]) -> String {
    b.iter()
        .map(|x| format!("{:02X}", x))
        .collect::<Vec<_>>()
        .join(":")
}

fn hex_short(b: &[u8]) -> String {
    if b.len() == 2 {
        format!("0x{:02X}{:02X}", b[0], b[1])
    } else {
        hex_bytes(b)
    }
}

fn msg_type_name(t: u32) -> &'static str {
    match t {
        0 => "UNKNOWN",
        1 => "ANNOUNCE",
        2 => "SET_BROKER",
        3 => "SYS_EVENT",
        4 => "UWB_ANCHOR_EVENT",
        5 => "UWB_TAG_EVENT",
        _ => "?",
    }
}

// --- live state -------------------------------------------------------------

#[derive(Clone, Copy, PartialEq, Eq)]
enum DeviceKind {
    Tag,
    Anchor,
    Unknown,
}

struct Device {
    name: String,
    kind: DeviceKind,
    ip: Option<[u8; 4]>,
    port: u32,
    msg_types: Vec<u32>,
    uwb_mac: Option<String>,
    wifi_mac: Option<String>,
    uptime_ms: u64,
    rssi: i32,
    last_seen: Instant,
}

impl Device {
    fn new(name: String) -> Self {
        Self {
            name,
            kind: DeviceKind::Unknown,
            ip: None,
            port: 0,
            msg_types: Vec::new(),
            uwb_mac: None,
            wifi_mac: None,
            uptime_ms: 0,
            rssi: 0,
            last_seen: Instant::now(),
        }
    }
}

struct Range {
    distance_m: f32,
    rx_power_db: f32,
    last_seen: Instant,
}

struct UwbApp {
    rx: mpsc::Receiver<Event>,
    devices: HashMap<u32, Device>,
    ranges: HashMap<u32, HashMap<String, Range>>,
    listening: bool,
    listen_addr: String,
    last_error: Option<String>,
    packets: u64,
}

impl UwbApp {
    fn new(cc: &eframe::CreationContext<'_>) -> Self {
        let (tx, rx) = mpsc::channel();
        let ctx = cc.egui_ctx.clone();
        std::thread::spawn(move || udp_loop(ctx, tx));

        Self {
            rx,
            devices: HashMap::new(),
            ranges: HashMap::new(),
            listening: false,
            listen_addr: LISTEN_ADDR.to_string(),
            last_error: None,
            packets: 0,
        }
    }

    fn handle(&mut self, ev: Event) {
        self.packets += 1;
        let now = Instant::now();
        match ev {
            Event::Listening { addr } => {
                self.listen_addr = addr;
                self.listening = true;
            }
            Event::Error(e) => self.last_error = Some(e),
            Event::Announce {
                src,
                device,
                ip,
                port,
                msg_types,
            } => {
                let d = self
                    .devices
                    .entry(src)
                    .or_insert_with(|| Device::new(format!("dev_{:08X}", src)));
                d.name = device;
                d.ip = ip;
                d.port = port;
                d.msg_types = msg_types;
                d.kind = if d.msg_types.contains(&MSG_UWB_TAG_EVENT) {
                    DeviceKind::Tag
                } else if d.msg_types.contains(&MSG_UWB_ANCHOR_EVENT) {
                    DeviceKind::Anchor
                } else {
                    DeviceKind::Unknown
                };
                d.last_seen = now;
            }
            Event::Sys {
                src,
                uptime_ms,
                rssi,
                ip,
                mac,
            } => {
                let d = self
                    .devices
                    .entry(src)
                    .or_insert_with(|| Device::new(format!("dev_{:08X}", src)));
                d.uptime_ms = uptime_ms;
                d.rssi = rssi;
                if let Some(ip) = ip {
                    d.ip = Some(ip);
                }
                if let Some(mac) = mac {
                    d.wifi_mac = Some(hex_bytes(&mac));
                }
                d.last_seen = now;
            }
            Event::Anchor { src, uwb_mac } => {
                let d = self
                    .devices
                    .entry(src)
                    .or_insert_with(|| Device::new(format!("dev_{:08X}", src)));
                d.uwb_mac = Some(hex_bytes(&uwb_mac));
                d.kind = DeviceKind::Anchor;
                d.last_seen = now;
            }
            Event::Tag {
                src,
                uwb_mac,
                anchor,
                distance_m,
                rx_power_db,
            } => {
                let mac_hex = hex_bytes(&uwb_mac);
                let d = self
                    .devices
                    .entry(src)
                    .or_insert_with(|| Device::new(mac_hex.clone()));
                d.uwb_mac = Some(mac_hex.clone());
                d.kind = DeviceKind::Tag;
                if d.name.starts_with("dev_") {
                    d.name = mac_hex.clone();
                }
                d.last_seen = now;

                let anchor_key = hex_short(&anchor);
                self.ranges
                    .entry(src)
                    .or_default()
                    .insert(
                        anchor_key,
                        Range {
                            distance_m,
                            rx_power_db,
                            last_seen: now,
                        },
                    );
            }
            Event::SetBroker { src, ip, port } => {
                self.last_error = Some(format!(
                    "device {src:08X} requested broker switch to {}:{}",
                    fmt_ip(ip),
                    port
                ));
            }
            Event::Unknown { src, msg_type } => {
                self.last_error = Some(format!(
                    "undecodable {}({msg_type}) from {src:08X}",
                    msg_type_name(msg_type)
                ));
            }
        }
    }

    fn device_label(&self, src: u32) -> String {
        match self.devices.get(&src) {
            Some(d) => d.name.clone(),
            None => format!("{src:08X}"),
        }
    }
}

fn udp_loop(ctx: egui::Context, tx: mpsc::Sender<Event>) {
    let socket = match UdpSocket::bind(LISTEN_ADDR) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("UDP bind failed: {e}");
            let _ = tx.send(Event::Error(format!("bind {LISTEN_ADDR}: {e}")));
            ctx.request_repaint();
            return;
        }
    };
    if let Err(e) = socket.set_nonblocking(true) {
        let _ = tx.send(Event::Error(format!("set_nonblocking: {e}")));
    }

    let _ = tx.send(Event::Listening {
        addr: LISTEN_ADDR.to_string(),
    });
    ctx.request_repaint();

    let mut buf = [0u8; 2048];
    loop {
        match socket.recv_from(&mut buf) {
            Ok((n, _peer)) => {
                if let Some(envelope) = decode_envelope(&buf[..n]) {
                    let ev = decode_payload(envelope.src, envelope.msg_type, &envelope.payload);
                    let _ = tx.send(ev);
                    ctx.request_repaint();
                }
            }
            Err(ref e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                std::thread::sleep(Duration::from_millis(1));
            }
            Err(e) => {
                let _ = tx.send(Event::Error(format!("recv: {e}")));
                ctx.request_repaint();
                std::thread::sleep(Duration::from_millis(100));
            }
        }
    }
}

impl eframe::App for UwbApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        while let Ok(ev) = self.rx.try_recv() {
            self.handle(ev);
        }

        egui::TopBottomPanel::top("status").show(ctx, |ui| {
            ui.add_space(4.0);
            ui.horizontal(|ui| {
                ui.heading("UWB UDP dashboard");
                ui.separator();
                ui.label("UDP");
                if self.listening {
                    ui.colored_label(egui::Color32::GREEN, "listening");
                } else {
                    ui.colored_label(egui::Color32::YELLOW, "binding…");
                }
                ui.monospace(&self.listen_addr);
                ui.label(format!("{} pkts", self.packets));
            });
            if let Some(e) = &self.last_error {
                ui.horizontal(|ui| {
                    ui.colored_label(egui::Color32::LIGHT_RED, "last event:");
                    ui.label(e);
                });
            }
            ui.add_space(4.0);
        });

        egui::SidePanel::left("devices")
            .resizable(true)
            .default_width(360.0)
            .show(ctx, |ui| {
                ui.heading("Devices");
                ui.separator();
                if self.devices.is_empty() {
                    ui.label("No devices announced yet.");
                    return;
                }

                let mut ids: Vec<u32> = self.devices.keys().copied().collect();
                ids.sort();

                egui::ScrollArea::vertical()
                    .auto_shrink([false, false])
                    .show(ui, |ui| {
                        for id in ids {
                            let d = &self.devices[&id];
                            ui.group(|ui| {
                                ui.horizontal(|ui| {
                                    ui.strong(&d.name);
                                    let (color, label) = match d.kind {
                                        DeviceKind::Tag => (egui::Color32::LIGHT_BLUE, "tag"),
                                        DeviceKind::Anchor => (egui::Color32::LIGHT_GREEN, "anchor"),
                                        DeviceKind::Unknown => (egui::Color32::GRAY, "?"),
                                    };
                                    ui.colored_label(color, label);
                                    ui.with_layout(
                                        egui::Layout::right_to_left(egui::Align::Center),
                                        |ui| {
                                            ui.monospace(format!(
                                                "{:.0}s",
                                                d.last_seen.elapsed().as_secs_f32()
                                            ));
                                        },
                                    );
                                });
                                ui.monospace(format!("{}:{}", fmt_ip(d.ip), d.port));
                                ui.horizontal(|ui| {
                                    ui.label(format!("rssi {} dBm", d.rssi));
                                    ui.label(format!("up {} s", d.uptime_ms / 1000));
                                });
                                if let Some(mac) = &d.uwb_mac {
                                    ui.monospace(format!("uwb {mac}"));
                                }
                                if let Some(mac) = &d.wifi_mac {
                                    ui.monospace(format!("wifi {mac}"));
                                }
                                if !d.msg_types.is_empty() {
                                    let s = d
                                        .msg_types
                                        .iter()
                                        .map(|&t| msg_type_name(t))
                                        .collect::<Vec<_>>()
                                        .join(", ");
                                    ui.label(egui::RichText::new(s).weak());
                                }
                            });
                            ui.add_space(4.0);
                        }
                    });
            });

        egui::CentralPanel::default().show(ctx, |ui| {
            ui.heading("Ranging");
            ui.separator();
            if self.ranges.is_empty() {
                ui.label("Waiting for UWB tag events…");
                return;
            }

            let mut tags: Vec<u32> = self.ranges.keys().copied().collect();
            tags.sort();

            let now = Instant::now();
            egui::ScrollArea::vertical()
                .auto_shrink([false, false])
                .show(ui, |ui| {
                    for tag in tags {
                        ui.strong(format!("tag {}", self.device_label(tag)));
                        let anchors = &self.ranges[&tag];
                        let mut keys: Vec<&String> = anchors.keys().collect();
                        keys.sort();

                        egui::Grid::new(egui::Id::new(("tag_grid", tag)))
                            .striped(true)
                            .num_columns(4)
                            .show(ui, |ui| {
                                ui.strong("Anchor");
                                ui.strong("Distance");
                                ui.strong("RX power");
                                ui.strong("Age");
                                ui.end_row();

                                for key in keys {
                                    let r = &anchors[key];
                                    let age_s = now.duration_since(r.last_seen).as_secs_f32();
                                    ui.monospace(key.as_str());
                                    ui.monospace(format!("{:.2} m", r.distance_m));
                                    ui.monospace(format!("{:.1} dBm", r.rx_power_db));
                                    ui.monospace(format!("{:.1} s", age_s));
                                    ui.end_row();
                                }
                            });
                        ui.add_space(8.0);
                    }
                });
        });
    }
}

fn main() {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default().with_inner_size([900.0, 600.0]),
        ..Default::default()
    };

    eframe::run_native(
        "UWB UDP dashboard",
        options,
        Box::new(|cc| Box::new(UwbApp::new(cc))),
    )
    .expect("failed to start eframe");
}

// ---------------------------------------------------------------------------
// tests: a mirror of the firmware encoder (uwb_proto.h) validates the decoder
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    struct W {
        buf: Vec<u8>,
    }

    impl W {
        fn new() -> Self {
            Self { buf: Vec::new() }
        }
        fn varint(&mut self, mut v: u64) {
            while v >= 0x80 {
                self.buf.push((v as u8) | 0x80);
                v >>= 7;
            }
            self.buf.push(v as u8);
        }
        fn tag(&mut self, field: u32, wire: u32) {
            self.varint(((field as u64) << 3) | wire as u64);
        }
        fn u32(&mut self, field: u32, v: u32) {
            self.tag(field, WIRE_VARINT);
            self.varint(v as u64);
        }
        fn i32(&mut self, field: u32, v: i32) {
            self.tag(field, WIRE_VARINT);
            self.varint(v as i64 as u64);
        }
        fn bytes(&mut self, field: u32, b: &[u8]) {
            self.tag(field, WIRE_LEN);
            self.varint(b.len() as u64);
            self.buf.extend_from_slice(b);
        }
        fn str(&mut self, field: u32, s: &str) {
            self.bytes(field, s.as_bytes());
        }
        fn f32(&mut self, field: u32, v: f32) {
            self.tag(field, WIRE_FIXED32);
            self.buf.extend_from_slice(&v.to_le_bytes());
        }
        fn packed_u32(&mut self, field: u32, vals: &[u32]) {
            let mut tmp = W::new();
            for &v in vals {
                tmp.varint(v as u64);
            }
            self.bytes(field, &tmp.buf);
        }
        fn envelope(&mut self, src: u32, msg_type: u32, payload: &[u8]) {
            self.u32(1, src);
            self.u32(2, 0);
            self.u32(3, msg_type);
            self.bytes(4, payload);
        }
    }

    #[test]
    fn roundtrip_tag_event() {
        let mut p = W::new();
        p.bytes(1, &[0x7d, 0x00, 0x22, 0xea, 0x82, 0x60, 0x3b, 0x9c]);
        p.bytes(2, &[0xdf, 0x97]);
        p.f32(3, 0.29);
        p.f32(4, -84.1);

        let mut e = W::new();
        e.envelope(0x1234_5678, MSG_UWB_TAG_EVENT, &p.buf);

        let env = decode_envelope(&e.buf).expect("decode envelope");
        assert_eq!(env.src, 0x1234_5678);
        assert_eq!(env.msg_type, MSG_UWB_TAG_EVENT);

        match decode_payload(env.src, env.msg_type, &env.payload) {
            Event::Tag {
                src,
                uwb_mac,
                anchor,
                distance_m,
                rx_power_db,
            } => {
                assert_eq!(src, 0x1234_5678);
                assert_eq!(uwb_mac, vec![0x7d, 0x00, 0x22, 0xea, 0x82, 0x60, 0x3b, 0x9c]);
                assert_eq!(anchor, vec![0xdf, 0x97]);
                assert!((distance_m - 0.29).abs() < 0.001);
                assert!((rx_power_db - (-84.1)).abs() < 0.01);
            }
            other => panic!("expected Tag, got {other:?}"),
        }
    }

    #[test]
    fn roundtrip_announce() {
        let mut p = W::new();
        p.str(1, "uwb_anchor_1");
        p.packed_u32(2, &[MSG_SYS_EVENT, MSG_UWB_ANCHOR_EVENT]);
        p.bytes(3, &[192, 168, 0, 121]);
        p.u32(4, 41234);

        let mut e = W::new();
        e.envelope(0x0000_0042, MSG_ANNOUNCE, &p.buf);

        let env = decode_envelope(&e.buf).unwrap();
        match decode_payload(env.src, env.msg_type, &env.payload) {
            Event::Announce {
                src,
                device,
                ip,
                port,
                msg_types,
            } => {
                assert_eq!(src, 0x0000_0042);
                assert_eq!(device, "uwb_anchor_1");
                assert_eq!(ip, Some([192, 168, 0, 121]));
                assert_eq!(port, 41234);
                assert_eq!(msg_types, vec![MSG_SYS_EVENT, MSG_UWB_ANCHOR_EVENT]);
            }
            other => panic!("expected Announce, got {other:?}"),
        }
    }

    #[test]
    fn roundtrip_sys_event_negative_rssi() {
        let mut p = W::new();
        p.tag(1, WIRE_VARINT);
        p.varint(35977);
        p.bytes(2, &[0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]);
        p.bytes(3, &[192, 168, 0, 55]);
        p.i32(4, -65);

        let mut e = W::new();
        e.envelope(0xdead_beef, MSG_SYS_EVENT, &p.buf);

        let env = decode_envelope(&e.buf).unwrap();
        match decode_payload(env.src, env.msg_type, &env.payload) {
            Event::Sys {
                src,
                uptime_ms,
                rssi,
                ip,
                mac,
            } => {
                assert_eq!(src, 0xdead_beef);
                assert_eq!(uptime_ms, 35977);
                assert_eq!(rssi, -65);
                assert_eq!(ip, Some([192, 168, 0, 55]));
                assert_eq!(mac, Some([0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]));
            }
            other => panic!("expected Sys, got {other:?}"),
        }
    }
}

